#include <iostream>

void add5(int*, int*);

int main(void){
	int* a = new int(3);
	int* b = new int(4);

	add5(a, b);

	std::cout << "a is :" << *a << " b is : " << *b;

	delete a, b;

	return 0;
}

void add5(int* a, int* b){
	*a = *a + 5;
	*b = *b + 5;
}